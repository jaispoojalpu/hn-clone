export const mobile = '@media only screen and  (max-width: 480px)';
export const tablet = '@media only screen and  (max-width: 768px)';
export const monitor = '@media only screen and  (min-width: 1400px)';
